import 'package:flutter/material.dart';
import 'dart:convert' as convert;
import 'api/LogIn.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ACT Money Transfer',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(title: 'ACT Money Transfer'),
      debugShowCheckedModeBanner: false,
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title}) : super(key: key);

  // STATE - variable
  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  String? userName, password;

  void _handleButtonPress() {
    if (((userName?.isEmpty??true) || (password?.isEmpty??true))==false) {
    //print("$userName $password");
      try {
        final data = LogIn(userName!, password);
        if (data == false) {
          ScaffoldMessenger.of(context)
              .showSnackBar(
              const SnackBar(content: Text("Invalid username or password!")));
        } else {
          ScaffoldMessenger.of(context)
              .showSnackBar(const SnackBar(content: Text("LogIn Successful!")));
        }
      } on Exception catch (e) { 			// Anything else that is an exception
        print('Error: $e');
      } catch (e) {						// No specified type, handles all
        print('unknown Error : $e');
      }

    } else {
      print('User Name and password can''t be empty!');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Scrollbar(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              const Text(
                "User LogIn",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
              ),
              const SizedBox(
                height: 20,
              ),
              const Text("User Name"),
              TextField(
                autofocus: true,
                keyboardType: TextInputType.name,
                onChanged: (String value) {
                  userName = value;
                },
              ),
              const SizedBox(
                height: 20,
              ),
              const Text("Password"),
              TextField(
                keyboardType: TextInputType.visiblePassword,
                onChanged: (String value) {
                  password = value;
                },
              ),
              TextButton(
                style: TextButton.styleFrom(
                  textStyle: const TextStyle(fontSize: 20),
                ),
                onPressed: _handleButtonPress,
                child: const Text('LogIn'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
