import 'dart:convert';
import 'package:http/http.dart' as http;

Future<dynamic> LogIn(String userName, password) async {
  // add validation here

  final response = await http.post(
    //Uri.parse('http://192.168.178.28:8080/api/account/create'),
    Uri.parse(
        'http://localhost:9095/api/user/logIn/'+userName+"/"+password)
   /*, headers: <String, String>{
      'Content-Type': 'application/json',
    },
    body: jsonEncode(<String, String>{
      'userName': userName,
      'password': password
    }),*/
  );

  if (response.statusCode == 200) {
    // If the server did return a 200 CREATED response,
    // then parse the JSON.
    final data = jsonDecode(response.body);
    print(data);
    return data;
  } else {
    // If the server did not return a 201 CREATED response,
    // then throw an exception.
    throw Exception('LogIn failed.'+response.statusCode.toString()+" : "+response.body);
  }
}
